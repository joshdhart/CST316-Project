﻿CREATE TABLE Genre(

  genreID INT PRIMARY KEY,

  type VARCHAR(50)

);