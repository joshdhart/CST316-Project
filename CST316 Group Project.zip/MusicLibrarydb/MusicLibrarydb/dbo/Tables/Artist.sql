﻿CREATE TABLE Artist(

  artistID INT PRIMARY KEY,

  name VARCHAR(255)

);